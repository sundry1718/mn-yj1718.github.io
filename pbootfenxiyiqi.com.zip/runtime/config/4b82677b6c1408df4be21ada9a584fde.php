<?php
return array (
  'lgs' => 
  array (
    'cn' => 
    array (
      'id' => '1',
      'acode' => 'cn',
      'pcode' => '0',
      'name' => '中文',
      'domain' => '',
      'is_default' => '1',
      'create_user' => 'admin',
      'update_user' => 'admin',
      'create_time' => '2017-11-30 13:55:37',
      'update_time' => '2018-04-13 11:40:49',
      'theme' => 'default',
    ),
  ),
);