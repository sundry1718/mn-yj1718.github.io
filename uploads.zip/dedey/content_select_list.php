<?php
/**
 * ѡ������
 *
 * @version        $Id: content_select_list.php 1 14:31 2010��7��12��Z tianya $
 * @package        DedeCMS.Administrator
 * @copyright      Copyright (c) 2007 - 2010, DesDev, Inc.
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */
$s_tmplets = "templets/content_select_list.htm";
include(dirname(__FILE__)."/content_list.php");
